Feature: Functionality test Login of SauceDemo application

  Background:
    Given User is on the SauceDemo login page

  #Functionality to check invalid credentials lead to unsuccessful login
  @smoke @regression @negative @TC_002
  Scenario: T_02 Verify that user should not be able to login with invalid credentials
    When I attempt login with invalid credentials
    Then I should see an authentication error message
    And I should remain on the login page
