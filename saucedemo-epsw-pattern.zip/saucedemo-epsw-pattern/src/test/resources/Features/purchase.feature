Feature: Purchase flow of SauceDemo application

  Background:
    Given User is on the SauceDemo login page

  #Functionality to check the end-to-end purchase of a single product
  @smoke @regression @TC_001
  Scenario: T_01 Successful purchase of a single product
    When I login as a standard user
    Then I should see the products page
    When I add "Sauce Labs Backpack" to the cart
    Then the cart badge should show "1"
    When I open the cart
    Then the cart should contain "Sauce Labs Backpack"
    When I checkout with valid customer details
    Then I should see the order confirmation page
