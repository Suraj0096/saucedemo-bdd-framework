package hooks;

import base.BaseTest;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.PropertyExtract;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Hooks {

    private static final Logger LOG = LoggerFactory.getLogger(Hooks.class);

    private BaseTest baseTest;

    @Before
    public void LaunchBrowser(Scenario scenario) {
        LOG.info("START: {}", scenario.getName());
        baseTest = new BaseTest();
        baseTest.invokeDriver(); // fresh browser per scenario => isolation and safe parallel runs
    }

    @After
    public void tearDown(Scenario scenario) {
        WebDriver driver = BaseTest.getDriver();
        try {
            if (scenario.isFailed() && driver != null) {
                byte[] png = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.attach(png, "image/png", scenario.getName()); // embedded in the HTML report
                saveToDisk(scenario.getName(), png);
                LOG.error("FAILED: {}", scenario.getName());
            }
        } finally {
            if (driver != null) driver.quit(); // always release the browser
            if (baseTest != null) baseTest.removeThread();
            LOG.info("END: {} [{}]", scenario.getName(), scenario.getStatus());
        }
    }

    private void saveToDisk(String scenarioName, byte[] png) {
        try {
            Path dir = Paths.get(PropertyExtract.get("screenshot.dir", "target/screenshots"));
            Files.createDirectories(dir);
            Files.write(dir.resolve(scenarioName.replaceAll("[^a-zA-Z0-9]+", "_") + "_" + System.currentTimeMillis() + ".png"), png);
        } catch (IOException e) {
            LOG.warn("Could not save screenshot to disk: {}", e.getMessage());
        }
    }
}
