package StepDefinitions;

import PageObjects.CartPage;
import PageObjects.CheckoutPage;
import PageObjects.ProductsPage;
import base.BaseTest;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import utils.PropertyExtract;
import utils.TestDataReader;

import java.util.List;

public class PurchaseStepDef {

    private ProductsPage productsPage() { return new ProductsPage(BaseTest.getDriver()); }
    private CartPage cartPage() { return new CartPage(BaseTest.getDriver()); }
    private CheckoutPage checkoutPage() { return new CheckoutPage(BaseTest.getDriver()); }

    @When("I add {string} to the cart")
    public void i_add_to_the_cart(String productName) {
        productsPage().addToCart(productName);
    }

    @Then("the cart badge should show {string}")
    public void the_cart_badge_should_show(String expectedCount) {
        Assert.assertEquals(productsPage().getCartBadgeCount(), expectedCount, "Cart badge count");
    }

    @When("I open the cart")
    public void i_open_the_cart() {
        productsPage().openCart();
    }

    @Then("the cart should contain {string}")
    public void the_cart_should_contain(String productName) {
        Assert.assertEquals(cartPage().getItemNames(), List.of(productName), "Cart items");
    }

    @When("I checkout with valid customer details")
    public void i_checkout_with_valid_customer_details() {
        cartPage().startCheckout();
        checkoutPage().fillCustomerInfo(TestDataReader.checkout("valid"));
        checkoutPage().finishOrder();
    }

    @Then("I should see the order confirmation page")
    public void i_should_see_the_order_confirmation_page() {
        Assert.assertTrue(checkoutPage().currentUrl().contains(PropertyExtract.getHelperData("url.checkout.complete")),
                "Should be on the checkout-complete page");
        Assert.assertEquals(checkoutPage().getCompleteHeader(), PropertyExtract.getHelperData("order.complete.header"),
                "Order confirmation header");
    }
}
