package StepDefinitions;

import PageObjects.LoginPage;
import PageObjects.ProductsPage;
import base.BaseTest;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import utils.Credentials;
import utils.PropertyExtract;
import utils.TestDataReader;

/** Step definitions only call page methods - no selectors here. */
public class LoginStepDef {

    // Page objects are created per call from the current thread's driver => parallel-safe
    private LoginPage loginPage() { return new LoginPage(BaseTest.getDriver()); }
    private ProductsPage productsPage() { return new ProductsPage(BaseTest.getDriver()); }

    @Given("User is on the SauceDemo login page")
    public void user_is_on_the_sauce_demo_login_page() {
        loginPage().launchApplication();
    }

    @When("I login as a standard user")
    public void i_login_as_a_standard_user() {
        Credentials user = TestDataReader.user("standard");
        loginPage().login(user.username(), user.password());
    }

    @When("I attempt login with invalid credentials")
    public void i_attempt_login_with_invalid_credentials() {
        Credentials user = TestDataReader.user("invalid");
        loginPage().login(user.username(), user.password());
    }

    @Then("I should see the products page")
    public void i_should_see_the_products_page() {
        Assert.assertEquals(productsPage().getPageTitle(), PropertyExtract.getHelperData("page.title.products"), "Products page title");
        Assert.assertTrue(productsPage().currentUrl().contains(PropertyExtract.getHelperData("url.inventory")),
                "URL should be the inventory page");
    }

    @Then("I should see an authentication error message")
    public void i_should_see_an_authentication_error_message() {
        Assert.assertTrue(loginPage().getErrorMessage().contains(PropertyExtract.getHelperData("error.invalid.login")),
                "Authentication error message");
    }

    @Then("I should remain on the login page")
    public void i_should_remain_on_the_login_page() {
        Assert.assertTrue(loginPage().isOnLoginPage(), "User should still be on the login page");
    }
}
