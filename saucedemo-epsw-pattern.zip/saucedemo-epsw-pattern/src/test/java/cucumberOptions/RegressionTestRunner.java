package cucumberOptions;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/** Regression suite (@regression). Run via regression-testng.xml. */
@CucumberOptions(features = "src/test/resources/Features",
        glue = {"StepDefinitions", "hooks"},
        tags = "@regression",
        plugin = {"pretty", "html:target/htmlreports/regression-report.html", "json:target/htmlreports/regression-report.json"},
        monochrome = true)
public class RegressionTestRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
