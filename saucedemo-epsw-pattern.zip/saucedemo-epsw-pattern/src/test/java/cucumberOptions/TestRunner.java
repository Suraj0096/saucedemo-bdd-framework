package cucumberOptions;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/** Smoke suite (@smoke). Run via smoke-testng.xml. Tags can be overridden: -Dcucumber.filter.tags="@negative" */
@CucumberOptions(features = "src/test/resources/Features",
        glue = {"StepDefinitions", "hooks"},
        tags = "@smoke",
        plugin = {"pretty", "html:target/htmlreports/report.html", "json:target/htmlreports/report.json"},
        monochrome = true)
public class TestRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
