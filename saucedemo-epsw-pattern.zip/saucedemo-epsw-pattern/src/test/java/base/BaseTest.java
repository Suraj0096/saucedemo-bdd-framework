package base;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.PropertyExtract;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Driver factory. One WebDriver per thread (ThreadLocal) so scenarios can run in parallel.
 * Selenium Manager (Selenium 4.6+) downloads the matching browser driver automatically - no driver path needed.
 */
public class BaseTest {

    private static final Logger LOG = LoggerFactory.getLogger(BaseTest.class);

    private static final ThreadLocal<WebDriver> tldriver = new ThreadLocal<>();

    public WebDriver invokeDriver() {
        String browserName = PropertyExtract.get("browser", "chrome");
        boolean headless = PropertyExtract.getBoolean("headless", true);
        LOG.info("Starting {} (headless={})", browserName, headless);

        WebDriver driver;
        if (browserName.equalsIgnoreCase("chrome")) {
            ChromeOptions options = new ChromeOptions();
            options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
            options.setExperimentalOption("useAutomationExtension", false);
            options.addArguments("--disable-extensions");
            options.setAcceptInsecureCerts(true);
            if (headless) options.addArguments("--headless=new");
            options.addArguments("--disable-dev-shm-usage", "--no-sandbox", "--disable-blink-features=AutomationControlled");
            // Stop Chrome's save-password / leaked-password popups from covering the page
            Map<String, Object> prefs = new HashMap<>();
            prefs.put("credentials_enable_service", false);
            prefs.put("profile.password_manager_enabled", false);
            prefs.put("profile.password_manager_leak_detection", false);
            options.setExperimentalOption("prefs", prefs);
            driver = new ChromeDriver(options);
        } else if (browserName.equalsIgnoreCase("edge")) {
            EdgeOptions options = new EdgeOptions();
            if (headless) options.addArguments("--headless=new");
            driver = new EdgeDriver(options);
        } else if (browserName.equalsIgnoreCase("firefox")) {
            FirefoxOptions options = new FirefoxOptions();
            if (headless) options.addArguments("-headless");
            driver = new FirefoxDriver(options);
        } else {
            throw new IllegalArgumentException("Unsupported browser '" + browserName + "' (use chrome | edge | firefox)");
        }

        // No implicit wait: explicit waits only (see utils.Helper). Mixing both gives unpredictable timeouts.
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PropertyExtract.getInt("pageload.timeout", 30)));
        driver.manage().window().setSize(new Dimension(1920, 1080));
        tldriver.set(driver);
        return driver;
    }

    /** Driver of the current thread/scenario. */
    public static WebDriver getDriver() {
        return tldriver.get();
    }

    public void removeThread() {
        tldriver.remove();
    }
}
