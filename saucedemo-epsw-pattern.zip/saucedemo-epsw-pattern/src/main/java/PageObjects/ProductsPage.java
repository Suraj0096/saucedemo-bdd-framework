package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.Helper;
import utils.PropertyExtract;

public class ProductsPage {

    private static final Logger LOG = LoggerFactory.getLogger(ProductsPage.class);

    private final WebDriver driver;
    private final Helper helper;

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        this.helper = new Helper(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "[data-test='title']")
    private WebElement pageTitle;

    @FindBy(css = "[data-test='shopping-cart-badge']")
    private WebElement cartBadge;

    @FindBy(css = "[data-test='shopping-cart-link']")
    private WebElement cartLink;

    /**
     * ROBUST (preferred): anchor on the product's visible NAME, climb to its card, then take the button inside that card.
     * No index, no absolute path; survives re-ordering/sorting, new products and layout changes.
     * (CSS cannot select a parent by its child's text, so a short relative XPath is the right tool here.)
     */
    static By addToCartByCard(String productName) {
        return By.xpath("//*[@data-test='inventory-item'][.//*[@data-test='inventory-item-name' "
                + "and normalize-space()=" + xpathLiteral(productName) + "]]"
                + "//button[starts-with(@data-test,'add-to-cart')]");
    }

    /**
     * FALLBACK (acceptable, less ideal): the dedicated data-test id derived from the name,
     * e.g. add-to-cart-sauce-labs-backpack. Stable today, but couples the test to a naming convention.
     */
    static By addToCartByDataTest(String productName) {
        String slug = productName.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        return By.cssSelector("[data-test='add-to-cart-" + slug + "']");
    }

    public String getPageTitle() {
        return helper.getText(pageTitle);
    }

    public String currentUrl() {
        return driver.getCurrentUrl();
    }

    public void addToCart(String productName) {
        helper.visibilityOf(pageTitle); // page is ready before we probe for the button
        By preferred = addToCartByCard(productName);
        if (driver.findElements(preferred).size() == 1) {
            helper.clickElement(preferred);
        } else {
            LOG.warn("Primary locator did not resolve to exactly one button for '{}'; using data-test fallback", productName);
            helper.clickElement(addToCartByDataTest(productName));
        }
    }

    public String getCartBadgeCount() {
        return helper.getText(cartBadge);
    }

    public void openCart() {
        helper.clickElement(cartLink);
        helper.urlContains(PropertyExtract.getHelperData("url.cart"));
    }

    /** Safely quotes text for XPath (handles apostrophes). */
    private static String xpathLiteral(String s) {
        if (!s.contains("'")) return "'" + s + "'";
        return "concat('" + s.replace("'", "', \"'\", '") + "')";
    }
}
