package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.Helper;
import utils.PropertyExtract;

public class LoginPage {

    private static final Logger LOG = LoggerFactory.getLogger(LoginPage.class);

    private final WebDriver driver;
    private final Helper helper;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.helper = new Helper(driver);
        PageFactory.initElements(driver, this);
    }

    // Centralised locators: SauceDemo exposes stable data-test attributes
    @FindBy(css = "[data-test='username']")
    private WebElement usernameBox;

    @FindBy(css = "[data-test='password']")
    private WebElement passwordBox;

    @FindBy(css = "[data-test='login-button']")
    private WebElement loginButton;

    @FindBy(css = "[data-test='error']")
    private WebElement errorMsg;

    public void launchApplication() {
        driver.get(PropertyExtract.get("url"));
        helper.visibilityOf(loginButton);
    }

    public void login(String username, String password) {
        LOG.info("Logging in as '{}'", username);
        helper.sendKeys(usernameBox, username);
        helper.sendKeys(passwordBox, password);
        helper.clickElement(loginButton);
    }

    public String getErrorMessage() {
        return helper.getText(errorMsg);
    }

    public boolean isOnLoginPage() {
        return !driver.getCurrentUrl().contains(PropertyExtract.getHelperData("url.inventory"))
                && helper.isDisplayed(loginButton);
    }
}
