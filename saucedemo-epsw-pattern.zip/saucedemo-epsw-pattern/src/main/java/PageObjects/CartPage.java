package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.Helper;
import utils.PropertyExtract;

import java.util.List;

public class CartPage {

    private static final By ITEM_NAMES = By.cssSelector("[data-test='inventory-item-name']");

    private final Helper helper;

    public CartPage(WebDriver driver) {
        this.helper = new Helper(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "[data-test='checkout']")
    private WebElement checkoutButton;

    public List<String> getItemNames() {
        return helper.textsOf(ITEM_NAMES);
    }

    public void startCheckout() {
        helper.clickElement(checkoutButton);
        helper.urlContains(PropertyExtract.getHelperData("url.checkout.step1"));
    }
}
