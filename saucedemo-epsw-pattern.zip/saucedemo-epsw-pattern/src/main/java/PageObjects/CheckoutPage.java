package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.CheckoutInfo;
import utils.Helper;
import utils.PropertyExtract;

public class CheckoutPage {

    private final WebDriver driver;
    private final Helper helper;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.helper = new Helper(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "[data-test='firstName']")
    private WebElement firstName;

    @FindBy(css = "[data-test='lastName']")
    private WebElement lastName;

    @FindBy(css = "[data-test='postalCode']")
    private WebElement postalCode;

    @FindBy(css = "[data-test='continue']")
    private WebElement continueButton;

    @FindBy(css = "[data-test='finish']")
    private WebElement finishButton;

    @FindBy(css = "[data-test='complete-header']")
    private WebElement completeHeader;

    public void fillCustomerInfo(CheckoutInfo info) {
        helper.sendKeys(firstName, info.firstName());
        helper.sendKeys(lastName, info.lastName());
        helper.sendKeys(postalCode, info.postalCode());
        helper.clickElement(continueButton);
        helper.urlContains(PropertyExtract.getHelperData("url.checkout.step2"));
    }

    public void finishOrder() {
        helper.clickElement(finishButton);
        helper.urlContains(PropertyExtract.getHelperData("url.checkout.complete"));
    }

    public String getCompleteHeader() {
        return helper.getText(completeHeader);
    }

    public String currentUrl() {
        return driver.getCurrentUrl();
    }
}
