package utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Config-driven JDBC helper. Each call opens a connection, runs a parameterised statement and closes everything
 * with try-with-resources => no leaks, clean teardown even when the test fails.
 * Any JDBC driver on the classpath works (PostgreSQL included; change db.url + driver for MySQL/SQL Server/Oracle).
 */
public class DbUtil {

    private static final Logger LOG = LoggerFactory.getLogger(DbUtil.class);

    public static class DbException extends RuntimeException {
        public DbException(String message) { super(message); }
        public DbException(String message, Throwable cause) { super(message, cause); }
    }

    private static Connection connect() {
        if (!PropertyExtract.getBoolean("db.enabled", false)) {
            throw new DbException("DB access is disabled. Set db.enabled=true plus db.url/db.user/db.password (properties, -D or env vars).");
        }
        try {
            DriverManager.setLoginTimeout(PropertyExtract.getInt("db.connect.timeout", 5));
            return DriverManager.getConnection(
                    PropertyExtract.get("db.url"), PropertyExtract.get("db.user"), PropertyExtract.get("db.password"));
        } catch (SQLException e) {
            throw new DbException("Could not connect to DB: " + e.getMessage(), e);
        }
    }

    /** SELECT with positional (?) parameters; returns rows as column-label -> value maps. */
    public static List<Map<String, Object>> query(String sql, Object... params) {
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setQueryTimeout(PropertyExtract.getInt("db.query.timeout", 10));
            bind(ps, params);
            LOG.debug("SQL: {}", sql);
            try (ResultSet rs = ps.executeQuery()) {
                return toList(rs);
            }
        } catch (SQLException e) {
            throw new DbException("Query failed: " + e.getMessage(), e);
        }
    }

    /** INSERT / UPDATE / DELETE (test-data cleanup). Returns affected rows. */
    public static int update(String sql, Object... params) {
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setQueryTimeout(PropertyExtract.getInt("db.query.timeout", 10));
            bind(ps, params);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new DbException("Update failed: " + e.getMessage(), e);
        }
    }

    /** Eventual consistency: poll until the query returns at least one row, or fail with a clear message. */
    public static List<Map<String, Object>> waitForRows(String sql, long timeoutMs, long intervalMs, Object... params) {
        return Helper.pollUntil(() -> query(sql, params), rows -> !rows.isEmpty(),
                timeoutMs, intervalMs, "DB rows for query: " + sql);
    }

    private static void bind(PreparedStatement ps, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
    }

    private static List<Map<String, Object>> toList(ResultSet rs) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        ResultSetMetaData meta = rs.getMetaData();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (int c = 1; c <= meta.getColumnCount(); c++) {
                row.put(meta.getColumnLabel(c), rs.getObject(c));
            }
            rows.add(row);
        }
        return rows;
    }
}
