package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Predicate;

/**
 * Wait utilities + safe actions. Explicit, condition-based waits only (no implicit wait, no Thread.sleep for UI).
 */
public class Helper {

    private static final Logger LOG = LoggerFactory.getLogger(Helper.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    public Helper(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(PropertyExtract.getInt("timeout", 10)));
        this.wait.pollingEvery(Duration.ofMillis(250));
        // The SPA re-renders the DOM after navigation; retry instead of failing on a stale reference
        this.wait.ignoring(StaleElementReferenceException.class);
    }

    public WebElement visibilityOf(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement visibilityOf(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public List<WebElement> visibilityOfAll(By locator) {
        return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
    }

    /** Waits until the elements exist and are visible, then reads their text in one stale-safe step. */
    public List<String> textsOf(By locator) {
        return wait.until(d -> {
            List<WebElement> elements = d.findElements(locator);
            if (elements.isEmpty()) return null;
            List<String> texts = new ArrayList<>();
            for (WebElement e : elements) {
                if (!e.isDisplayed()) return null;
                texts.add(e.getText());
            }
            return texts;
        });
    }

    public WebElement elementToBeClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public WebElement elementToBeClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public void urlContains(String fragment) {
        wait.until(ExpectedConditions.urlContains(fragment));
    }

    public boolean isDisplayed(WebElement element) {
        try {
            visibilityOf(element);
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    /** Normal click once clickable; JavaScript click only as a last resort when something overlays the element. */
    public void clickElement(WebElement element) {
        elementToBeClickable(element);
        try {
            element.click();
        } catch (ElementClickInterceptedException e) {
            LOG.warn("Click intercepted, retrying with JavaScript click");
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }

    public void clickElement(By locator) {
        clickElement(elementToBeClickable(locator));
    }

    public void sendKeys(WebElement element, String text) {
        visibilityOf(element).clear();
        element.sendKeys(text);
    }

    public String getText(WebElement element) {
        return visibilityOf(element).getText();
    }

    /**
     * Bounded polling for NON-UI systems (e.g. DB eventual consistency): retry until accept(value) is true
     * or the timeout expires. Exceptions are treated as "not ready yet".
     */
    public static <T> T pollUntil(Callable<T> action, Predicate<T> accept, long timeoutMs, long intervalMs, String description) {
        long deadline = System.currentTimeMillis() + timeoutMs;
        Exception last = null;
        while (true) {
            try {
                T value = action.call();
                if (accept.test(value)) return value;
                last = null;
            } catch (Exception e) {
                last = e;
            }
            if (System.currentTimeMillis() >= deadline) break;
            try {
                Thread.sleep(intervalMs); // justified: bounded back-off between polls of a non-UI system
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Interrupted while waiting for " + description, ie);
            }
        }
        throw new IllegalStateException("Timed out after " + timeoutMs + "ms waiting for " + description
                + (last != null ? "; last error: " + last.getMessage() : ""), last);
    }
}
