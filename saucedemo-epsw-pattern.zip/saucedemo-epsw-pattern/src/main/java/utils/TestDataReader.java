package utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;

/** Reads fixture-style JSON test data from src/test/resources/TestData. */
public class TestDataReader {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static JsonNode node(String file, String key) {
        try (InputStream in = TestDataReader.class.getClassLoader().getResourceAsStream("TestData/" + file)) {
            if (in == null) throw new IllegalStateException("Test data file not found: TestData/" + file);
            JsonNode n = MAPPER.readTree(in).get(key);
            if (n == null) throw new IllegalArgumentException("Key '" + key + "' not found in " + file);
            return n;
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read test data " + file, e);
        }
    }

    public static Credentials user(String key) {
        try {
            return MAPPER.treeToValue(node("users.json", key), Credentials.class);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static CheckoutInfo checkout(String key) {
        try {
            return MAPPER.treeToValue(node("checkout.json", key), CheckoutInfo.class);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
