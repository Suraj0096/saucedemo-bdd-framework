package utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Properties;

/**
 * Environment-based property reader.
 * Files:  Properties/&lt;env&gt;-config.properties  and  Properties/&lt;env&gt;-helper.properties  (env = -Denv=..., default "test").
 * Precedence for config keys:  -Dkey  &gt;  environment variable (KEY_NAME)  &gt;  &lt;env&gt;-config.properties
 */
public class PropertyExtract {

    private static final String ENV = resolveEnv();
    private static final Properties CONFIG = load(String.format("Properties/%s-config.properties", ENV), true);
    private static final Properties HELPER = loadHelper();

    private static String resolveEnv() {
        String env = System.getProperty("env");
        if (env == null || env.isBlank()) env = System.getenv("ENV");
        return (env == null || env.isBlank()) ? "test" : env.trim();
    }

    private static Properties load(String resource, boolean required) {
        Properties props = new Properties();
        try (InputStream in = PropertyExtract.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                if (required) throw new IllegalStateException("Missing property file on classpath: " + resource);
                return null;
            }
            props.load(in);
            return props;
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read " + resource, e);
        }
    }

    private static Properties loadHelper() {
        Properties p = load(String.format("Properties/%s-helper.properties", ENV), false);
        return p != null ? p : load("Properties/test-helper.properties", true); // fall back to the default data
    }

    /** All config properties of the selected environment. */
    public Properties getPropertyDetails() {
        return CONFIG;
    }

    /** All helper/expected-data properties of the selected environment. */
    public Properties getData() {
        return HELPER;
    }

    public static String get(String key) {
        String value = System.getProperty(key);
        if (value == null || value.isBlank()) value = System.getenv(key.toUpperCase().replace('.', '_'));
        if (value == null || value.isBlank()) value = CONFIG.getProperty(key);
        return value == null ? null : value.trim();
    }

    public static String get(String key, String defaultValue) {
        String v = get(key);
        return (v == null || v.isEmpty()) ? defaultValue : v;
    }

    public static int getInt(String key, int defaultValue) {
        String v = get(key);
        return (v == null || v.isEmpty()) ? defaultValue : Integer.parseInt(v);
    }

    public static boolean getBoolean(String key, boolean defaultValue) {
        String v = get(key);
        return (v == null || v.isEmpty()) ? defaultValue : Boolean.parseBoolean(v);
    }

    /** Expected text / constants from the helper file. */
    public static String getHelperData(String key) {
        String v = HELPER.getProperty(key);
        if (v == null) throw new IllegalArgumentException("Key '" + key + "' not found in helper properties");
        return v.trim();
    }
}
