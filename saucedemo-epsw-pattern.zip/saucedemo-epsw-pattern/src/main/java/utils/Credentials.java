package utils;

public record Credentials(String username, String password) { }
