package utils;

public record CheckoutInfo(String firstName, String lastName, String postalCode) { }
