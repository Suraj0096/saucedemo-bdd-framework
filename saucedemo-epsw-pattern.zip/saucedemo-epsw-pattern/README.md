# SauceDemo BDD Automation Framework (Java · Selenium 4 · Cucumber · TestNG · Maven)

Target application: https://www.saucedemo.com

## 1. Project structure (and mapping to the required folders)

| Required folder | Location in this repo | Contents |
|---|---|---|
| `/features` | `src/test/resources/Features` | Gherkin only: `login.feature`, `purchase.feature` |
| `/steps` | `src/test/java/StepDefinitions` | `LoginStepDef`, `PurchaseStepDef` – call page methods, **no selectors** |
| `/pages` | `src/main/java/PageObjects` | `LoginPage`, `ProductsPage`, `CartPage`, `CheckoutPage` – locators (`@FindBy`) + actions |
| `/support` or `/utils` | `src/main/java/utils` + `src/test/java/base` + `src/test/java/hooks` | `Helper` (waits/safe actions), `PropertyExtract`, `TestDataReader`, `DbUtil` (DB), `BaseTest` (driver factory), `Hooks` (Before/After, screenshot on failure, logging via SLF4J/Logback) |
| `/config` | `src/test/resources/Properties` | `test-config.properties`, `test-helper.properties`, `.env.example` |
| `/testdata` | `src/test/resources/TestData` | `users.json`, `checkout.json` |
| Runners | `src/test/java/cucumberOptions` | `TestRunner` (@smoke), `RegressionTestRunner` (@regression) |
| Suites | project root | `smoke-testng.xml`, `regression-testng.xml` (parallel: `data-provider-thread-count="2"`) |
| CI (bonus) | `.github/workflows/ci.yml` | GitHub Actions |

## 2. Setup and how to run

Prerequisites: JDK 17+, Maven 3.8+, Chrome (or Firefox/Edge). No manual driver download: Selenium Manager (Selenium 4.6+) resolves the driver automatically.

```bash
mvn clean install -DskipTests           # install dependencies
mvn clean test                          # smoke suite (default: smoke-testng.xml, @smoke)
mvn clean test -DsuiteXmlFile=regression-testng.xml          # regression suite (@regression)
mvn test -Dcucumber.filter.tags="@negative"                  # run by tag
mvn test -Dheadless=false                                    # watch the browser
mvn test -Dbrowser=firefox                                   # chrome | edge | firefox
mvn test -Denv=test                                          # picks Properties/test-config.properties (default)
mvn test -Durl=https://www.saucedemo.com
```

Reports: `target/htmlreports/report.html` (HTML report, bonus) and `report.json`. Failure screenshots are embedded in the HTML report and saved under `target/screenshots/`.

**Change browser / headless mode:** edit `browser=` / `headless=` in `Properties/test-config.properties`, or override at runtime with `-Dbrowser=...` / `-Dheadless=...` or the env vars `BROWSER` / `HEADLESS`.
Precedence: `-D` option > environment variable > `Properties/<env>-config.properties`.
**New environment:** add `Properties/<env>-config.properties` (and optionally `<env>-helper.properties`) and run with `-Denv=<env>`.

### Assumptions
- The SauceDemo credentials in `TestData/users.json` are the public demo accounts printed on the login page, not secrets. Real secrets (DB password) must come from env vars / CI secrets, never from git.
- Each scenario starts its own browser (ThreadLocal driver), so scenarios are independent and parallel-safe.
- SauceDemo has no database, so the DB utility is implemented but disabled (`db.enabled=false`).
- Step definitions create page objects from `BaseTest.getDriver()` (current thread), so no static state is shared between threads.

## 3. Locator Strategy for Adding "Sauce Labs Backpack"

**Preferred (implemented: `ProductsPage.addToCartByCard`)** – anchor on the product's visible *name*, climb to its card, then take the button inside that card:

```xpath
//*[@data-test='inventory-item'][.//*[@data-test='inventory-item-name' and normalize-space()='Sauce Labs Backpack']]
   //button[starts-with(@data-test,'add-to-cart')]
```
Why it is robust: it identifies the product by what a user identifies it with (its name), not its position. It survives re-ordering/sorting, new products, markup changes and id renames. It is short and relative (two `data-test` anchors), not a brittle chain, and it is parameterised, so the product name comes from the feature file (`I add "Sauce Labs Backpack" to the cart`). CSS cannot select a parent by its child's text, so a small relative XPath is the right tool for this one case; every other locator is a CSS `data-test` selector.

**Fallback (implemented, used only when the preferred locator does not resolve to exactly one button: `ProductsPage.addToCartByDataTest`)**

```css
[data-test='add-to-cart-sauce-labs-backpack']
```
Less ideal: it depends on a naming convention developers could change, and it is a different locator per product. Still much better than index-based selection (`get(0)`, `(//button)[1]`) or an absolute path such as `/html/body/div[1]/div/div/...`.

**Avoided:** index-based selection, long/absolute XPath chains, style-class selectors.

## 4. Database testing design

### 4.1 DB connection utility (`utils/DbUtil.java`)
- **Config-driven:** `db.enabled`, `db.url`, `db.user`, `db.password`, timeouts come from `PropertyExtract` (properties file, `-D`, or env vars `DB_URL`, `DB_USER`, `DB_PASSWORD`).
- **Query execution:** `query(sql, params...)` – parameterised (`?`), returns rows as `List<Map<String,Object>>`; `update(...)` for cleanup.
- **Error handling:** everything is wrapped in `DbException` with a clear message; DB disabled fails fast with instructions; login and query timeouts are set.
- **Clean teardown:** connection, statement and result set are closed by try-with-resources on every call, so nothing leaks even when the test fails.
- **Eventual consistency:** `waitForRows(sql, timeoutMs, intervalMs, params...)` polls through `Helper.pollUntil`.
- Works with any JDBC driver on the classpath (PostgreSQL included); change `db.url` and the driver dependency for MySQL/SQL Server/Oracle.

### 4.2 Pseudocode – validating a UI action in the DB

```gherkin
@db
Scenario: Order is persisted after checkout
  When I login as a standard user
  And I add "Sauce Labs Backpack" to the cart
  And I checkout with valid customer details
  Then I should see the order confirmation page
  And the order for this test run should exist in the database
```

```java
// Before: unique identity per scenario => isolation
String runId = "qa_" + System.currentTimeMillis() + "_" + Thread.currentThread().getId();
CheckoutInfo info = new CheckoutInfo("QA", runId, "411001");   // lastName carries the run id through the UI

// ... UI flow completes ...

// Then: validate the DB record, tolerating asynchronous writes
String sql = """
    SELECT o.order_id, o.status, o.total_amount, i.item_sku
      FROM orders o JOIN order_items i ON i.order_id = o.order_id
     WHERE o.customer_last_name = ? AND i.item_sku = ?
     ORDER BY o.created_at DESC""";

var rows = DbUtil.waitForRows(sql, 15_000, 500, runId, "sauce-labs-backpack");  // retry logic
Assert.assertEquals(rows.size(), 1, "exactly one order row");
Assert.assertEquals(rows.get(0).get("status"), "CONFIRMED");

// After (@After("@db") hook, runs even on failure): cleanup
DbUtil.update("DELETE FROM order_items WHERE order_id IN (SELECT order_id FROM orders WHERE customer_last_name = ?)", runId);
DbUtil.update("DELETE FROM orders WHERE customer_last_name = ?", runId);
```

- **Isolation strategy:** every scenario writes data tagged with a unique `runId` and queries only by it, so parallel threads and other users never collide; use a dedicated test schema/tenant, never production.
- **Cleanup strategy:** delete by `runId` in an `@After("@db")` hook (child tables first). Alternatives: rollback-only transaction, scheduled purge of `qa_%` rows, restoring a seeded snapshot.
- **Eventual consistency:** no fixed sleep; bounded polling (timeout + short interval) that fails with the last error / row count.
- **Security:** read-only DB account for validation; credentials from CI secrets.

## 5. Engineering notes

1. **Why this structure?** It separates concerns: features describe behaviour in business language, step definitions are thin glue, page objects own all UI knowledge, `utils` holds reusable tooling, `base` creates the driver, `hooks` owns the scenario lifecycle, and properties/test data live outside the code. A UI change touches one page object; a business change touches one feature file. Separate runners and TestNG suites (smoke/regression) allow different scopes and parallelism.
2. **Wait strategy / flakiness:** explicit `WebDriverWait` + `ExpectedConditions` (visibility, clickability, URL change) in `Helper`. No implicit wait (mixing it with explicit waits causes unpredictable timeouts) and no `Thread.sleep` in UI code; the one sleep in `pollUntil` is a documented bounded back-off for non-UI systems (DB). Every page action waits for its own precondition, and navigations wait for the next URL, so steps never race the browser. JavaScript click is used only as a fallback when a normal click is intercepted.
3. **Locators and stability:** all locators are centralised in page objects, use `data-test` attributes or the product name instead of position, and the Backpack locator has a fallback. Re-ordering the catalogue or restyling the page does not break them.
4. **Scaling to 50+ scenarios:** small page objects (extract header/cart components), parameterised reusable steps (`I add {string} to the cart`), Scenario Outlines + JSON data, tags (`@smoke`, `@regression`, `@db`), parallel execution (ThreadLocal driver + parallel data provider; raise `data-provider-thread-count` or use Selenium Grid/Docker), API/cookie login for tests that don't test login, split step classes by domain, and trend the JSON reports.
5. **CI/CD:** `.github/workflows/ci.yml` runs `mvn test` on JDK 17 for every push/PR (smoke), uploads reports and screenshots as artifacts; regression runs nightly or on merge to main with `-DsuiteXmlFile=regression-testng.xml`. `-Denv`, URL and DB secrets are injected as environment variables. The same Maven command works in Jenkins/Azure DevOps/GitLab; Selenium Grid or `selenium/standalone-chrome` for scale.
6. **Two improvements with more time:** (a) ExtentReports/Allure with trends plus a TestNG `IRetryAnalyzer` for known-flaky failures; (b) log in through a cookie/API for non-login tests (faster, fewer failure points) and a Testcontainers database so the `@db` scenario runs end to end.

## 6. Bonus included
Tag-based execution (`@smoke`, `@regression`, `@negative`), HTML reporting, parallel execution (`data-provider-thread-count="2"`), and a GitHub Actions workflow.

## 7. AI / Copilot usage disclosure

- **AI tools used:** Yes, Claude (Anthropic).
- **AI-assisted parts:**
    - First draft of the framework code: pom.xml, property reader, driver factory (BaseTest), hooks, helper/wait utilities, page objects, step definitions, DB utility, TestNG suite files and the GitHub Actions file.
    - First draft of this README, including the locator strategy, DB pseudocode and engineering notes.
    - A fix for a StaleElementReferenceException found during my run, which came from the AI.
- **What I did myself and why:**
    - Chose the package layout (PageObjects, utils, base, cucumberOptions, hooks, StepDefinitions, Features, Properties) to match the framework pattern I already use in my work.
    - Set up JDK 17 and Maven, imported the project into IntelliJ, and ran the smoke suite myself (2 scenarios, both passing).
    - Found the stale element failure on the cart page in my own test run and applied the fix (`Helper.textsOf` and retry on stale elements).
    - Ran the tests in headed mode, by tag and in parallel to check how they behave.

